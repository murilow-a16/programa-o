var nome = `Pedro`;
console.log(nome);
const sobrenome = `soares`;
console.log(sobrenome);

var nome = "Laredo";
const ip = "127.0.0.1";
console.log(nome);
console.log(ip);

// const ip = "127.0.1.1";não pode alterar uma constante;
// console.log(ip);
