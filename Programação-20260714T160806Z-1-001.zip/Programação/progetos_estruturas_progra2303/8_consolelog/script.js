let idade = "15";
//console.log(idade);

let nome = "felipe";
//console.log(nome);

console.log(`Meu nome é ${nome}, e tenho ${idade} anos`)