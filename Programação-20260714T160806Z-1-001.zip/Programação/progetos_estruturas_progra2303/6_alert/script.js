alert("Se inscreva no meu canal");
alert("Rem certeza que já se inscreveu no meu canal?")
alert("Rem certeza que já se inscreveu no meu canal?")
alert("Rem certeza que já se inscreveu no meu canal?")
alert("Rem certeza que já se inscreveu no meu canal?")
alert("Rem certeza que já se inscreveu no meu canal?")