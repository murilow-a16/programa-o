console.log(typeof "oi meu nome é felipe");
console.log(typeof 'Eu queria comprar um carro!');
console.log(typeof `Teste`);
console.log(typeof "infinity");
console.log(typeof Infinity);