let MAX_HEIGHT = 250;
console.log(`Sua altura maxima é ${MAX_HEIGHT}`);