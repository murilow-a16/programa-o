let number = prompt("Digite um número");
alert(number*2);
console.log(number * 2);