let a = 10;
let b = 5;
let c = a+b;
console.log(c);
alert(`O valor da soma de a + b ${c}`);