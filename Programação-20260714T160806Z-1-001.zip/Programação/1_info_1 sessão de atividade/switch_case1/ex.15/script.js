let tipo = prompt("qual o quadrante S, NO, SE, CO, NE").toUpperCase;

switch (tipo){
    case "S":
        alert("Sul");
        alert("O valor do frete sera 20 reais")
        break
    case "NO":
        alert("Nordeste");
        alert("O valor do frete sera 45 reais")
        break
    case "SE":
        alert("Sudeste");
        alert("O valor do frete sera 25 reais")
        break
    case "CO":
        alert("Centro oeste");
        alert("O valor do frete sera 35 reais")
        break
    case "NE":
        alert("Nordeste");
        alert("O valor do frete sera 40 reais")
        break
    default:
        alert("dados invalidos");
}