let tipo = prompt("qual o codigo A, B, C, D").toUpperCase;
let quantidade = +prompt("consumo");
let valor;

switch (tipo){
    case "A":
        valor = quantidade*90;
        alert(` ${valor}`)
        break
    case "B":
        valor = quantidade*150;
        alert(` ${valor}`)
        break
    case "C":
        valor = quantidade*250;
        alert(` ${valor}`)
        break
    case "D":
        valor = quantidade*400;
        alert(` ${valor}`)
        break
    default:
        alert("daddos invalidos");

}

