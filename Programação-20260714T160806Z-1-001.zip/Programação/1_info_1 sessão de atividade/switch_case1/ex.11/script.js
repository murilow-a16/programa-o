let consumo = +prompt("qual a distancia");
let tipo = prompt("qual o tipo de converção R, C ou I").toUpperCase;

switch (tipo){
    case "R":
        alert(`o valor a pagar sera ${consumo*0.72}`);
        break
    case "C":
        alert(`o valor a pagar sera ${consumo*0.92}`);
        break
    case "I":
        alert(`o valor a pagar sera ${consumo*0.68}`);
        break
    default:
        alert("dados invalidos");
}
