let tipo = prompt("qual o codigo D, E, L, P").toUpperCase;
let quantidade = +prompt("valor em reais");
let valor;

switch (tipo){
    case "D":
        valor = quantidade/5.60;
        alert(` ${valor}`);
        break
    case "E":
        valor = quantidade/6.45;
        alert(` ${valor}`);
        break
    case "L":
        valor = quantidade/7.55;
        alert(` ${valor}`);
        break
    case "P":
        valor = quantidade/0.005;
        alert(` ${valor}`);
        break
    default:
        alert("daddos invalidos");
}

