let valor = +prompt("qual a distancia");
let tipo = prompt("qual o tipo de converção A, B ou C").toUpperCase;
let desconto;

switch (tipo){
    case "A":
        desconto = valor * 0.05;
        alert(`o valor a pagar sera ${valor - desconto} o valor do desconto é de ${desconto}`);
        break
    case "B":
        desconto = valor*0.10;
        alert(`o valor a pagar sera ${valor - desconto} o valor do desconto é de ${desconto}`);
        break
    case "C":
        desconto = valor*0.15;
        alert(`o valor a pagar sera ${valor - desconto} o valor do desconto é de ${desconto}`);
        break
    default:
        alert("dados invalidos");
}