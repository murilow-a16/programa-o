let tipo = ~~prompt("qual o tipo de media 1, 2, 3");
let nota1;
let nota2;
let nota3;
let nota4;
let media;

switch (tipo) {
    case "1":
        nota1 = +prompt("qual a nota 1");
        nota2 = +prompt("qual a nota 2");
        media = ((nota1 * 2) + (nota2*3)) / 5;
        alert(`a media da nota sera ${media}`)
        break
    case "2":
        nota1 = +prompt("qual a nota 1");
        nota2 = +prompt("qual a nota 2");
        nota3 = +prompt("qual a nota 3");
        media = ((nota1 * 2) + (nota2 * 3) + (nota3 * 5)) / 10;
        alert(`a media da nota sera ${media}`)
        break
    case "3":
        nota1 = +prompt("qual a nota 1");
        nota2 = +prompt("qual a nota 2");
        nota3 = +prompt("qual a nota 3");
        nota4 = +prompt("qual a nota 4");
        media = ((nota1*1) + (nota2*2) + (nota3*3) + (nota4*4)) / 10;
        alert(`a media da nota sera ${media}`)
        break
    default:
        alert("daddos invalidos");

}
