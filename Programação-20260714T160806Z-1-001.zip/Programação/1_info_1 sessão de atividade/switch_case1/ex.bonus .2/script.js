let tipo = ~~prompt("qual o tipo de cargo 1, 2, 3");
let horasT = +prompt("horas trabalhadas");
let horasE = +prompt("horas extras");
let salarioT;
let salarioE;
let salario;

switch (tipo){
    case "1":
        salarioT = horasT * 25;
        salarioE = horasE * 35;
        salario = salarioT + salarioE;
        alert(`categoria ${tipo}, horas trabalhadas ${horasT}, horas extras ${horasE}, valor normal ${salarioT}, valor pelas horas extras ${salarioE}, salario bruto ${salario}`);
        break
    case "2":
        salarioT = horasT * 40;
        salarioE = horasE * 60;
        salario = salarioT + salarioE;
        alert(`categoria ${tipo}, horas trabalhadas ${horasT}, horas extras ${horasE}, valor normal ${salarioT}, valor pelas horas extras ${salarioE}, salario bruto ${salario}`);
        break
    case "3":
        salarioT = horasT * 25;
        salarioE = horasE * 35;
        salario = salarioT + salarioE;
        alert(`categoria ${tipo}, horas trabalhadas ${horasT}, horas extras ${horasE}, valor normal ${salarioT}, valor pelas horas extras ${salarioE}, salario bruto ${salario}`);
        break
}