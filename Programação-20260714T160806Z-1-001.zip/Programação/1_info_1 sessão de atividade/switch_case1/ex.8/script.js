let curso = prompt("qual o curso voce deseja fazer 1, 2, 3");

switch (curso){
    case "1":
        alert("Informatica");
        break
    case "2":
        alert("Adiministração");
        break
    case "3":
        alert("Rede de computadores");
        break
    default:
        alert("Dados invalidos")
}

