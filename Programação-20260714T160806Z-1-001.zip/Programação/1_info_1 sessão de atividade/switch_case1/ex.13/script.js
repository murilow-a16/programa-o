let tipo = ~~prompt("qual o quadrante 1 a 5");

switch (tipo){
    case "1":
        alert("Norte");
        break
    case "2":
        alert("Nordeste");
        break
    case "3":
        alert("Centro-oeste");
        break
    case "4":
        alert("Suldeste");
        break
    case "5":
        alert("Sul");
        break
    default:
        alert("dados invalidos");
}

