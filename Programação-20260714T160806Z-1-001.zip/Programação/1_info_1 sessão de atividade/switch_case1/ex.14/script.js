let saldo = 1000;
let opcao = prompt("qual opção voce eseja");
let saque;
let deposito


switch (opcao){
    case "1":
        alert(`${saldo}`);
        break
    case "2":
        saque = +prompt("qual o valor de saque");
        if(saldo>saque){
            saldo = saldo-saque;
            alert(`o saldo da conta ficou ${saldo}`);
        }
        else{
            alert("saldo insuficiente para sacar");
        }
        break
    case "3":
        deposito = +prompt("qual o valor do deposito");
        saldo = saldo + deposito;
        alert(`o saldo da conta ficou ${saldo}`);
        break
    default:
        alert("dados invalidos");
}
