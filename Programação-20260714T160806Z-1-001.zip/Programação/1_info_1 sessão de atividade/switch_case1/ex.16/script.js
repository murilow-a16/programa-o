let tipo = prompt("qual o codigo B, P, E").toUpperCase;
let mensal = ~~prompt("quamtos meses voce deseja contratar");
let valor;

switch (tipo){
    case "B":
        valor = mensal*39.90;
        alert(`o plano sera Basico, o valor da mesalidade sera R$39,90, o quantidade de meses é ${mensal}, e o total sera ${valor}`)
        break
    case "P":
        valor = mensal*69.90;
        alert(`o plano sera Profissional, o valor da mesalidade sera R$69,90, o quantidade de meses é ${mensal}, e o total sera ${valor}`)
        break
    case "B":
        valor = mensal*119.90;
        alert(`o plano sera Basico, o valor da mesalidade sera R$119,90, o quantidade de meses é ${mensal}, e o total sera ${valor}`)
        break
    default:
        alert("daddos invalidos");

}

