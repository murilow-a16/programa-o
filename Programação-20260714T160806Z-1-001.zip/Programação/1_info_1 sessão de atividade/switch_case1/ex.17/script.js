let tipo = prompt("qual o codigo R, C, I").toUpperCase;
let consumo = +prompt("consumo");
let valor;

switch (tipo){
    case "R":
        valor = consumo*0.82;
        alert(` ${valor}`)
        break
    case "C":
        valor = consumo*0.95;
        alert(` ${valor}`)
        break
    case "I":
        valor = consumo*0.73;
        alert(` ${valor}`)
        break
    default:
        alert("daddos invalidos");

}

