let distancia = +prompt("qual a distancia");
let convercao = prompt("qual o tipo de converção 1 ou 2");

switch (convercao) {
    case "1":
        alert(`${distancia * 1000}Km`);
        break
    case "2":
        alert(`${distancia*0.001}m`);
        break
    default:
        alert("Dados invalidos");
}
