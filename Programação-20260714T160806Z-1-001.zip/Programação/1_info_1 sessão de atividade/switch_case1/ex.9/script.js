let meio = prompt("qual o meio de transporte voce usa C, M, B").toUpperCase;

switch (meio){
    case "C":
        alert("Carro");
        break
    case "M":
        alert("Moto");
        break
    case "B":
        alert("Bicicleta");
        break
    default:
        alert("Dados invalidos");
}
