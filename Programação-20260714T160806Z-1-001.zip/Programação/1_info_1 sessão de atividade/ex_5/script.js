let nome = prompt("digite sua instituição:");
let curso = prompt("digite seu curso:")
let semestre = prompt("digite seu semstre:");

alert(`Estudo no ${nome}, e realizo o curso ${curso}, e estou no semestre ${semestre}`);
console.log(`Estudo no ${nome}, e realizo o curso ${curso}, e estou no semestre ${semestre}`);