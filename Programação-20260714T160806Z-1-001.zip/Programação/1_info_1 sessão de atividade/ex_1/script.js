let resultado = Math.pow(2,2)
console.log(resultado)

let Resultado = Math.pow(3,2);
console.log(Resultado);

let resposta = Math.pow(18,2);
console.log(resposta);