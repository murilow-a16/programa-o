let base = prompt('qual a medida da base:');
let altura = prompt('qual a medida da altura');
let area = (base*altura) /2;
alert(`A medida da area é ${area}`);