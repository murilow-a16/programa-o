let n1 = Number(prompt("qual sua primeira nota:"));
let n2 = Number(prompt("qual sua segunda nota:"));
let n3 = Number(prompt("qual sua terceira nota:"));
let media = (n1 + n2 + n3) / 3;

alert(`Sua media sera ${media}`);
console.log(`sua media é ${media}`);