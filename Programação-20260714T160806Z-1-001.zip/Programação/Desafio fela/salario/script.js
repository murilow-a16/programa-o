let salarioBase = prompt('qual seu salario base');
let salario = 