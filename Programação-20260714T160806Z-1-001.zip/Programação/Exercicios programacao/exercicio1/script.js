console.log("Ola mundo! \n sou um robo");
console.log("quero ser um programador");
console.log("Meu nome é Felipe")