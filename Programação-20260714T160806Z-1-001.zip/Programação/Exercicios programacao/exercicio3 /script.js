console.log(2 > 1);
console.log(10 <= 20);
console.log(5 != 8);