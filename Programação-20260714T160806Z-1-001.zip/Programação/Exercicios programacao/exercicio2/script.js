console.log(2);
console.log(12.2);
console.log(2*3)