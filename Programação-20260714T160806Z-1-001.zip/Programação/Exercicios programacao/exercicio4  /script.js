console.log(false && false);
console.log(true||false);
console.log(!true);