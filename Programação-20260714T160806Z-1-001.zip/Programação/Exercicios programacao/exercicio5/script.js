console.log(NaN);
console.log(0/0)